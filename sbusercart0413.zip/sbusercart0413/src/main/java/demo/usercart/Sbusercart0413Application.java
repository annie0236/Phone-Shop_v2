package demo.usercart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sbusercart0413Application {

	public static void main(String[] args) {
		SpringApplication.run(Sbusercart0413Application.class, args);
	}

}

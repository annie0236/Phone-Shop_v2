package demo.usercart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sbusercart0413ApplicationTests {

	@Test
	void contextLoads() {
	}

}
